@echo off
echo Запуск KAYOR Browser...
start "" "index.html"
echo Открой index.html в браузере. Для нативной версии — собери Electron: npm run electron:build
pause
