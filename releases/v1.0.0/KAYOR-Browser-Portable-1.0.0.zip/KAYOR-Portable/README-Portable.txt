KAYOR Browser — портативная версия
===================================
1. Распакуй папку куда угодно (хоть на флешку)
2. Запусти Запустить-KAYOR.bat или открой index.html
3. Для нативной exe собери: installer.iss (Inno Setup) или installer.nsi (NSIS) -> получишь KAYOR-Setup.exe

Логотип: kayorbrowse.png (твой)
Тема: тёмная + стекло + красный
